﻿//create 2d cellular automata in c#
//simulates forest fire spread

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//create the cell class

namespace CellularAutomata
{
    class Cell
    {
        public int x;
        public int y;
        public int state;
        public int nextState;

        public Cell(int x, int y, int state)
        {
            this.x = x;
            this.y = y;
            this.state = state;
            this.nextState = state;
        }
    }
    //create three states for the cell

    public enum CellState
    {
        Empty = 0,
        Tree = 1,
        Fire = 2
    }

    //create the grid class

    class Grid
    {
        public int width;
        public int growthProbability = 48;
        public int fireProbability = 50;
        public int height;
        public Cell[,] cells;

        public Grid(int width, int height)
        {
            this.width = width;
            this.height = height;
            cells = new Cell[width, height];
        }

        public void Randomize()
        {
            Random random = new Random();
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    cells[x, y] = new Cell(x, y, random.Next(0, 2));
                }
            }
        }
        //set up cells to be all trees

        public void SetAllTrees()
        {
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    cells[x, y] = new Cell(x, y, 1);
                }
            }
        }

        //reset grid 

        public void resetGrid()
        {
            Random random = new Random();
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    cells[x, y] = new Cell(x, y, random.Next(0, 2));
                }
            }
        }
        //apply growthprobability to the grid
        public void applyGrowth()
        {
            Random random = new Random();
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    if (cells[x, y].state == (int)CellState.Empty)
                    {
                        if (random.Next(0, 100) < growthProbability)
                        {
                            cells[x, y].nextState = (int)CellState.Tree;
                        }
                    }
                }
            }
        }

        //start the fire

        public void StartFire(int x, int y)
        {
            cells[x, y].state = (int)CellState.Fire;
        }


        //print out the grid

        void Print()
        {
            for (int y = 0; y < height; y++)
            {
                for (int x = 0; x < width; x++)
                {
                    // Console.Write(cells[x, y].state);
                    switch (cells[x, y].state)
                    {
                        case 0:
                            Console.Write("_");
                            break;
                        case 1:
                            Console.Write("&");
                            break;
                        case 2:
                            Console.Write("x");
                            break;
                    }
                   
                }
                Console.WriteLine();
            }
        }

        //get the number of trees around a cell


        public int GetNumberOfTreesAroundCell(int x, int y)
        {
            int numberOfTrees = 0;
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (x + i >= 0 && x + i < width && y + j >= 0 && y + j < height)
                    {
                        if (cells[x + i, y + j].state == (int)CellState.Tree)
                        {
                            numberOfTrees++;
                        }
                    }
                }
            }
            return numberOfTrees;
        }

        //get the number of fires around a cell

        public int GetFires(int x, int y)
        {
            int numberOfFires = 0;
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (x + i >= 0 && x + i < width && y + j >= 0 && y + j < height)
                    {
                        if (cells[x + i, y + j].state == (int)CellState.Fire)
                        {
                            numberOfFires++;
                        }
                    }
                }
            }
            return numberOfFires;
        }




        public void Update()
        {
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    int neighbors = 0;
                    for (int i = -1; i < 2; i++)
                    {
                        for (int j = -1; j < 2; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                continue;
                            }
                            int neighborX = x + i;
                            int neighborY = y + j;
                            if (neighborX < 0 || neighborY < 0 || neighborX >= width || neighborY >= height)
                            {
                                continue;
                            }
                            neighbors += cells[neighborX, neighborY].state;
                        }
                    }
                    if (cells[x, y].state == 1)
                    {
                        if (neighbors < 2 || neighbors > 3)
                        {
                            cells[x, y].nextState = 0;
                        }
                    }
                    else
                    {
                        if (neighbors == 3)
                        {
                            cells[x, y].nextState = 1;
                        }
                    }
                }
            }
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    cells[x, y].state = cells[x, y].nextState;
                }
            }
        }

        //simulate forest fire spread

        public void UpdateFire()
        {
            Random random = new Random();
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    int neighbors = 0;
                    for (int i = -1; i < 2; i++)
                    {
                        for (int j = -1; j < 2; j++)
                        {
                            if (i == 0 && j == 0)
                            {
                                continue;
                            }
                            int neighborX = x + i;
                            int neighborY = y + j;
                            if (neighborX < 0 || neighborY < 0 || neighborX >= width || neighborY >= height)
                            {
                                continue;
                            }
                            neighbors += cells[neighborX, neighborY].state;
                        }
                    }
                    /*
                    if (cells[x, y].state == 1)
                    {
                        if (neighbors < 2 || neighbors > 3)
                        {
                            cells[x, y].nextState = 0;
                        }
                    }
                    else
                    {
                        if (neighbors == 3)
                        {
                            cells[x, y].nextState = 1;
                        }
                    }
                }
            }
            */
                    if (cells[x, y].state == (int)CellState.Empty)
                    {
                        if (random.Next(0, 100) < growthProbability)
                        {
                            cells[x, y].nextState = (int)CellState.Tree;
                        }
                    }
                    else if (cells[x, y].state == (int)CellState.Tree)
                    {
                        if (GetFires(x, y) > 0 || random.Next(0, 100) < fireProbability)
                        {
                            cells[x, y].nextState = (int)CellState.Fire;
                        }
                    }
                    else if (cells[x, y].state == (int)CellState.Fire)
                    {
                        cells[x, y].nextState = (int)CellState.Empty;
                    }
                    for (int i = 0; i < width; i++)
                    {
                        for (int j = 0; j < height; j++)
                        {
                            cells[i, j].state = cells[i, j].nextState;
                        }
                    }
                }
            }
        }



                //call reset on keypress R

                //initializing the code

                static void Main(string[] args)
                {
                    Console.WriteLine("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX \n ");
                    Console.WriteLine(" Welcome to my Fire simulation Model \n ");
                    Console.WriteLine(" please note the icon convention of model \n");
                    Console.WriteLine(" & represnet trees \n");
                    Console.WriteLine(" * represnet burning trees \n");
                    Console.WriteLine(" _ represnet clear ground \n");
                      Console.WriteLine(" press R to reset to inital starting point \n");
                      Console.WriteLine(" press T to perform another step \n");
            Console.WriteLine(" press A to reset array to all trees \n");
            Console.WriteLine("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX \n ");
                    Console.WriteLine(" \n");
                    Grid grid = new Grid(21, 21);

                    grid.Randomize();
                    grid.StartFire(10, 10);
                    grid.Print();
                    Console.WriteLine();
                    while (true)
                    {
                        grid.UpdateFire();
                        grid.Print();
                        Console.WriteLine();
                        Console.ReadKey();
                        if (Console.KeyAvailable)
                        {
                            if (Console.ReadKey(true).Key == ConsoleKey.R)
                            {
                                  grid.Randomize();
                                  grid.StartFire(10, 10);
                                   grid.Print();

                    }
                            //set all to trees
                             if (Console.ReadKey(true).Key==ConsoleKey.A)
                    {
                              grid.SetAllTrees();
                               grid.Print();
                    }

                            //start next timestep on t press

                            if (Console.ReadKey(true).Key == ConsoleKey.T)
                            {
                        //run update on nextstate grid
                        grid.UpdateFire();
                        grid.UpdateFire();
                        grid.Print();
                        Console.WriteLine();

                    }
                        }
                    }
                }

                //initializing the whole program



















    }
}